const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;
const MESSAGE = process.env.GREETING || 'Hello from KubeCore!';

app.get('/', (req, res) => {
  res.json({ message: MESSAGE, hostname: require('os').hostname() });
});

app.get('/healthz', (req, res) => {
  res.status(200).send('ok');
});

app.listen(PORT, () => {
  console.log(`hello-service listening on port ${PORT}`);
});
